package SistemaAtendimento;

public class Pilha {
    private Elemento topo;

    public Pilha() {
        topo = null;
    }

    public void empilhar(String id, String descricao, String dataHora) {
        Elemento novo = new Elemento(id, descricao, dataHora, null);
        novo.proximo = topo;
        topo = novo;
    }

    public void desempilhar() {
        if (estaVazia()) {
            System.out.println("Histórico vazio!");
        } else {
            System.out.println("Removido: " + topo.id + " - " + topo.descricao);
            topo = topo.proximo;
        }
    }

    public boolean estaVazia() {
        return topo == null;
    }

    public void exibirHistorico() {
        if (estaVazia()) {
            System.out.println("Histórico vazio.");
            return;
        }
        Elemento atual = topo;
        while (atual != null) {
            System.out.println(atual.id + " - " + atual.descricao + " (" + atual.dataHora + ")");
            atual = atual.proximo;
        }
    }
}
