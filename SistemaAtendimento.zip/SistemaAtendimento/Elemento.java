package SistemaAtendimento;

public class Elemento {
    String id;
    String descricao;
    String dataHora;
    String nomeCliente;
    Elemento proximo;

    public Elemento(String id, String descricao, String dataHora, String nomeCliente) {
        this.id = id;
        this.descricao = descricao;
        this.dataHora = dataHora;
        this.nomeCliente = nomeCliente;
        this.proximo = null;
    }
}
