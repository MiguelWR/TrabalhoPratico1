package SistemaAtendimento;

public class Fila {
    private Elemento frente;
    private Elemento tras;

    public Fila() {
        frente = null;
        tras = null;
    }

    public void enfileirar(String id, String nome, String motivo) {
        Elemento novo = new Elemento(id, motivo, null, nome);
        if (estaVazia()) {
            frente = novo;
            tras = novo;
        } else {
            tras.proximo = novo;
            tras = novo;
        }
    }

    public void atender() {
        if (estaVazia()) {
            System.out.println("Fila de atendimento vazia!");
        } else {
            System.out.println("Atendendo: " + frente.nomeCliente + " - " + frente.descricao);
            frente = frente.proximo;
            if (frente == null) {
                tras = null;
            }
        }
    }

    public boolean estaVazia() {
        return frente == null;
    }

    public void exibirFila() {
        if (estaVazia()) {
            System.out.println("Fila vazia.");
            return;
        }
        Elemento atual = frente;
        while (atual != null) {
            System.out.println(atual.id + " - " + atual.nomeCliente + ": " + atual.descricao);
            atual = atual.proximo;
        }
    }
}
