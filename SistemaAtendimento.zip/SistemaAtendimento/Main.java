package SistemaAtendimento;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Pilha historico = new Pilha();
        Fila atendimento = new Fila();
        Scanner entrada = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Adicionar Solicitação ao Histórico");
            System.out.println("2. Remover Solicitação do Histórico");
            System.out.println("3. Mostrar Histórico");
            System.out.println("4. Adicionar Cliente à Fila");
            System.out.println("5. Atender Cliente");
            System.out.println("6. Mostrar Fila de Atendimento");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            String opcao = entrada.nextLine();

            try {
                if (opcao.equals("1")) {
                    System.out.print("ID: ");
                    String id = entrada.nextLine();
                    System.out.print("Descrição: ");
                    String desc = entrada.nextLine();
                    System.out.print("Data e Hora: ");
                    String data = entrada.nextLine();
                    historico.empilhar(id, desc, data);

                } else if (opcao.equals("2")) {
                    historico.desempilhar();

                } else if (opcao.equals("3")) {
                    historico.exibirHistorico();

                } else if (opcao.equals("4")) {
                    System.out.print("ID do Cliente: ");
                    String id = entrada.nextLine();
                    System.out.print("Nome: ");
                    String nome = entrada.nextLine();
                    System.out.print("Motivo: ");
                    String motivo = entrada.nextLine();
                    atendimento.enfileirar(id, nome, motivo);

                } else if (opcao.equals("5")) {
                    atendimento.atender();

                } else if (opcao.equals("6")) {
                    atendimento.exibirFila();

                } else if (opcao.equals("0")) {
                    System.out.println("Encerrando o sistema...");
                    break;

                } else {
                    System.out.println("Opção inválida.");
                }

            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }

        entrada.close();
    }
}